import sun.awt.image.ImageWatched;

import java.util.LinkedList;

/**
 * Created by Alankar on 04-10-2015.
 */
public class HashElement {
    public LinkedList<WordEntry> entry=new LinkedList<WordEntry>();
}
