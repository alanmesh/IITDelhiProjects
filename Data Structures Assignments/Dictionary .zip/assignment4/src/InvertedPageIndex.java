import java.util.LinkedList;

/**
 * Created by Alankar on 04-10-2015.
 */
public class InvertedPageIndex {
    InvertedPageIndex(){
        pe=new MySet<PageEntry>();
        mht=new MyHashTable(500);
    }
    MySet<PageEntry> pe=new MySet<PageEntry>();
    MyHashTable mht=new MyHashTable(500);
    void addPage(PageEntry p){
        pe.addElement(p);
        MySet<WordEntry>a= p.PI.weSet;              //working!
        for(int i=1;i<=a.setLinkedList.size();i++){
            mht.addPositionsForWord(a.setLinkedList.get(i - 1));
         //   System.out.println(a.setLinkedList.get(i-1).str);
        }
    }

    MySet<PageEntry> getPagesWhichContainWord(String str1){
        int x=mht.hashFunction(str1);
        MySet<PageEntry> ab=new MySet<PageEntry>();
        try {

                HashElement cur = mht.newTable[x];
           // for(int i=1;i<=cur.entry.size();i++)
         //   System.out.println(cur.entry.get(i-1).str+"xxxxxxxxxxxxxxx");

                LinkedList<Position> qq = new LinkedList<Position>();
                for (int i = 1; i <= cur.entry.size(); i++) {
                    if (cur.entry.get(i-1).str.equals(str1)) {
                        qq = cur.entry.get(i-1).weLinkedList;
                        break;
                    }

                }
                for (int j = 1; j <= qq.size(); j++) {
                    ab.addElement(qq.get(j - 1).pEntry);
                }

            return ab;
        }
        catch (Exception e){
            System.out.println("Word not found");;
        }
        return ab;
    }
}


