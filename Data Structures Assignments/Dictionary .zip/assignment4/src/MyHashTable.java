import java.util.LinkedList;

/**
 * Created by Alankar on 04-10-2015.
 */
public class MyHashTable {
    public int tableSize;
    public int cardinality;
    public HashElement[] newTable;
    public int hashFunction(String s) {
        int x = s.hashCode();
        x %= tableSize;
        if (x < 0) x = tableSize + x;
        return x;
    }

    public MyHashTable(int s) {
        tableSize = s;
        cardinality = 0;
        newTable = new HashElement[tableSize];
        while (s != 0) {
            newTable[s - 1] = null;
            s--;
        }
    }

    public int getHashIndex(String str1) {
        return hashFunction(str1);
       /* int toReturn = -1;
        for (int i = 0; i < this.tableSize; i++) {
            if (newTable[i] != null) {
                HashElement temp = newTable[i];
                for (int j = 0; j < temp.entry.size(); j++) {
                    if (temp.entry.get(j).str.equals(str1)) {
                        toReturn = i;
                        break;
                    }
                }
            }
        }
            return toReturn;*/
    }


    void addPositionsForWord(WordEntry w){

        int a=hashFunction(w.str);
        boolean addingDone=false;
        String ss=w.str;
        if(newTable[a]!=null){
            HashElement temp = newTable[a];
            for(int i=1;i<=temp.entry.size();i++){
                if(temp.entry.get(i-1).str.equals(ss))
                {
                    temp.entry.get(i-1).addPositions(w.weLinkedList);
                    addingDone=true;
                    break;
                }
//                System.out.println(newTable[a].entry.get(i-1).str);

            }
            if(!addingDone){
                newTable[a].entry.add(w);
//                System.out.println(newTable[a].entry.get(0).str);
            }
        }
        else{
            newTable[a]=new HashElement();
            newTable[a].entry.add(w);
//            System.out.println(newTable[a].entry.get(0).str);
        }
    }
}

