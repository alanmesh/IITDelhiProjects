/**
 * Created by Alankar on 28-09-2015.
 */
import java.util.*; //import for using linkedlist
//new class
public class MySet<T>{

    LinkedList<T> setLinkedList=new LinkedList<T>();
    public Boolean IsEmpty(){
        return(setLinkedList.size()==0);
    }

    public Boolean IsMember(T o){
        return(setLinkedList.contains(o));
    }


    public void addElement(T o){
        if(!(setLinkedList.contains(o)))
            setLinkedList.add(o);


    }
    public void Delete(T o){
        setLinkedList.remove(o);
    }

    public MySet<T> intersection(MySet<T> a){
        MySet<T> op=new MySet<T>();


        for(int j=0;j<setLinkedList.size();j++)
        {
            if(a.IsMember(setLinkedList.get(j)))
                op.addElement(setLinkedList.get(j));
        }
        return op;

    }

    public MySet<T> Union(MySet<T> a)
    {
        MySet<T> op=new MySet<T>();
        for(int j=0;j<setLinkedList.size();j++)
        {
            op.addElement(setLinkedList.get(j));
        }
        for(int j=0;j<a.setLinkedList.size();j++)
        {
            op.addElement(a.setLinkedList.get(j));
        }
        return op;


    }




}
