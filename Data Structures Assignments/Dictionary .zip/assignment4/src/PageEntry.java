/**
 * Created by Alankar on 01-10-2015.
 */
import java.io.*;
import java.util.Scanner;
import java.util.regex.Pattern;

public class PageEntry {
    String pageName;
    public PageIndex PI=new PageIndex();
    PageEntry(String pn){
        this.pageName=pn;
        String pageAddress="webpages\\"+pageName;
        //Using Buffer reader
        BufferedReader bReader=null;
        String templine=null;
        try {

            bReader = new BufferedReader(new FileReader(pageAddress));
            String abc = "";
            while ((abc = bReader.readLine()) != null) {
                templine += " "+abc;
            }
        /*
        finally {
            try{
                if(bReader!=null)
                    bReader.close();
            }
            catch (IOException e2){
                System.out.println("handle this?");
            }
        }*/
            Scanner s = new Scanner(templine);


            int cur = 0;
            while (s.hasNext()) {
                Position tempPos = new Position(this, cur);
                String tempString = s.next().toLowerCase();


                if (tempString.equals("a") ||
                        tempString.equals("an") ||
                        tempString.equals("the") ||
                        tempString.equals("they") ||
                        tempString.equals("these") ||
                        tempString.equals("this") ||
                        tempString.equals("for") ||
                        tempString.equals("is") ||
                        tempString.equals("are") ||
                        tempString.equals("was") ||
                        tempString.equals("of") ||
                        tempString.equals("or") ||
                        tempString.equals("and") ||
                        tempString.equals("does") ||
                        tempString.equals("will") ||
                        tempString.equals("whose")) {
                    cur++;
                    continue;
                }

                else {
                    tempString=tempString.replace('{',' ');
                    tempString=tempString.replace('}',' ');
                    tempString=tempString.replace(']',' ');
                    tempString=tempString.replace('[',' ');
                    tempString=tempString.replace('<',' ');
                    tempString=tempString.replace('>',' ');
                    tempString=tempString.replace('=',' ');
                    tempString= tempString.replace('(',' ');
                    tempString= tempString.replace(')',' ');
                    tempString= tempString.replace('.',' ');
                    tempString= tempString.replace(',',' ');
                    tempString= tempString.replace(';',' ');
                    tempString= tempString.replace('\'',' ');
                    tempString= tempString.replace('\"',' ');
                    tempString= tempString.replace('?',' ');
                    tempString= tempString.replace('#',' ');
                    tempString= tempString.replace('!',' ');
                    tempString= tempString.replace('-',' ');
                    tempString= tempString.replace(':', ' ');
                    tempString= tempString.trim();
                  //  if(tempString.endsWith("s")){
                   //     tempString=tempString.substring(0,tempString.length()-1);
                    //}
                    PI.addPositionForWord(tempString, tempPos);
                 //   System.out.println(tempString);
                    cur++;
                }
            }
        }
            catch (Exception e1){
                System.out.println(e1);
            }
        }




    }







