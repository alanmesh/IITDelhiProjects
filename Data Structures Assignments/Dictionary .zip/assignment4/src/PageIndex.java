/**
 * Created by Alankar on 30-09-2015.
 */
import java.util.*;
public class PageIndex {
    MySet<WordEntry> weSet = new MySet<WordEntry>();


    void addPositionForWord(String str1, Position p){
        boolean flag=false;
        int temp=-99;
        str1=str1.toLowerCase();

            for (int i = 1; i <= weSet.setLinkedList.size(); i++) {
                String tempStr = weSet.setLinkedList.get(i - 1).str;
                if (tempStr.equals("stacks")) {
                    tempStr = "stack";
                }
                if (tempStr.equals("structures"))
                    tempStr = "structure";
                if (tempStr.equals("applications"))
                    tempStr = "application";
                if (tempStr.equals(str1)) {
                    flag = true;
                    temp = i - 1;
                    break;
                }
            }
            if (flag) {
                weSet.setLinkedList.get(temp).weLinkedList.add(p);
            } else {
                WordEntry we = new WordEntry(str1);
                we.addPosition(p);
                weSet.setLinkedList.add(we);
            }



    }


    LinkedList<WordEntry> getWordEntries(){
        LinkedList<WordEntry> toReturn=new LinkedList<WordEntry>();
        for(int i=1;i<=weSet.setLinkedList.size();i++){

            toReturn.add(this.weSet.setLinkedList.get(i-1));
        }
        return toReturn;
    }





}
