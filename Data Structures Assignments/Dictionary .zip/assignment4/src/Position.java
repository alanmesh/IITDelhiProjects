import javafx.geometry.Pos;
import java.util.*;
/**
 * Created by Alankar on 28-09-2015.
 */
public class Position {
    public PageEntry pEntry;
    public int wordIndex;
    public Position(PageEntry pe,int wi ){
        this.pEntry=pe;
        this.wordIndex=wi;

    }
    PageEntry getPageEntry(){
        return this.pEntry;
    }
    int getWordIndex(){
    return this.wordIndex;
    }










}
