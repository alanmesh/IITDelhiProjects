import java.util.LinkedList;
import java.util.Scanner;

/**
 * Created by Alankar on 28-09-2015.
 */
public class SearchEngine{
    InvertedPageIndex ipe=new InvertedPageIndex();

    public SearchEngine() {
        ipe=new InvertedPageIndex();
    }

    public void performAction(String actionMessage) {
        Scanner s =new Scanner(actionMessage);
        String newString=s.next();
        String a="",b="";
        if(s.hasNext())
            a=s.next().toLowerCase();
        if(s.hasNext())
            b=s.next().toLowerCase();
        System.out.println(actionMessage);
        if(newString.equals("addPage")){        //mostly working
            ipe.addPage(new PageEntry(a));
        }

        if(newString.equals("queryFindPagesWhichContainWord")){
            MySet<PageEntry> newest=ipe.getPagesWhichContainWord(a);

            for(int i=1;i<=newest.setLinkedList.size();i++){
                System.out.println(newest.setLinkedList.get(i-1).pageName+",");
            }

        }
        if(newString.equals("queryFindPositionsOfWordInAPage")){

           PageEntry naya=null;
            try {
                for (int i = 1; i <= ipe.pe.setLinkedList.size(); i++) {
                    if (ipe.pe.setLinkedList.get(i - 1).pageName.equals(b)) {
                        naya = ipe.pe.setLinkedList.get(i - 1);
                        break;
                    }
                }
                if (naya == null) {
                    throw new IllegalArgumentException("Webpage " + b + " doesn't exist.");
                }

                LinkedList<WordEntry> as = naya.PI.getWordEntries();
                boolean didPrintHappen = false;
                for (int i = 1; i <= as.size(); i++) {
                  // System.out.println(as.get(i-1).str);
                    if (as.get(i - 1).str.equals(a)) {
                        for(int j=1;j<=as.get(i-1).weLinkedList.size();j++)
                        {
                            if(as.get(i-1).weLinkedList.get(j-1).pEntry.pageName.equals(b))
                            System.out.println(as.get(i-1).weLinkedList.get(j-1).wordIndex);
                            didPrintHappen = true;
                        }
                        break;


                    }
                }
                if (!didPrintHappen) {
                    System.out.println("Webpage " + b + " does not contain word " + a);
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }



    }
}

