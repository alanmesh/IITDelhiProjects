import java.util.*;

/**
 * Created by Alankar on 29-09-2015.
 */
public class WordEntry {
    String str;
    LinkedList<Position> weLinkedList=new LinkedList<Position>();
    WordEntry(String word){
        this.str=word;
    }
    void addPosition(Position position){
        weLinkedList.add(position);
    }
    void addPositions(LinkedList<Position> positions){
        for(int i=1;i<=positions.size();i++){
            this.weLinkedList.add(positions.get(i-1));
        }
    }
    LinkedList<Position> getAllPositionsForThisWord(){
        return weLinkedList;
    }


}
