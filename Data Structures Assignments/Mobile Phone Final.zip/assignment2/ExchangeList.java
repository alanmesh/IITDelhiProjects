public class ExchangeList{
    LinkedList<Exchange> l=new LinkedList<Exchange>();

}