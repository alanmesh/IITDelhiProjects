import java.util.*;
public class MobilePhone{

    public int mobile_uid;
    public boolean present_status;
    MobilePhone(int number){
        mobile_uid=number;
        present_status=true;
    }

    public int number(){
        return mobile_uid;
    }
    public Boolean status() {
        return present_status;
    }
    public void switchOn(){

        present_status=true;
    }
    public void switchOff(){

        present_status=false;
    }
   /* public Exchange location(){


    }*/
}












