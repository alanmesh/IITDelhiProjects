import java.util.*;
public class MobilePhoneSet{
    LinkedList<MobilePhone> l=new LinkedList<MobilePhone>();
    public Boolean IsEmpty(){
        if(l.size()==0)
            return true;
        else return false;
    }
    public boolean IsMember(MobilePhone mp){
        if(l.contains(mp))
            return true;
        else return false;
    }
    public void Insert(MobilePhone mp){
        if(!(l.contains(mp)))
            l.add(mp);

    }
    public void Delete(MobilePhone mp){

        l.remove(mp);
    }
    //returns the ith element of the set...
    public MobilePhone getElementAtIndex(int i){
        return  l.get(i);
    }

    public MobilePhoneSet Intersection(MobilePhoneSet a){

        MobilePhoneSet op=new MobilePhoneSet();


        for(int j=0;j<this.l.size();j++)
        {
            if(a.IsMember(l.get(j)))
                op.Insert(l.get(j));
        }
        return op;

    }

    public MobilePhoneSet Union(MobilePhoneSet a)
    {
        MobilePhoneSet op=new MobilePhoneSet();
        for(int j=0;j<l.size();j++)
        {
            op.Insert(l.get(j));
        }
        for(int j=0;j<a.l.size();j++)
        {
            op.Insert(a.l.get(j));
        }
        return op;

    }
    public MobilePhone getElement(int mobid){
        MobilePhone aa=new MobilePhone(-1);
        for(int i=0;i<l.size();i++){
            if(l.get(i).mobile_uid==mobid) {
                aa = this.getElementAtIndex(i);
                break;
            }
        }
        return aa;

    }



}