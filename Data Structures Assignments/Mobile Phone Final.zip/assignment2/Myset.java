import java.util.*;
public class Myset{
    LinkedList l=new LinkedList();
    public Boolean IsEmpty(){
        if(l.size()==0)
            return true;
        else return false;
    }
    public Boolean IsMember(Object o){
        if(l.contains(o))
            return true;
            else return false;
    }
    public void Insert(Object o){
        if(!(l.contains(o)))
            l.add(o);

    }
    public void Delete(Object o){
        l.remove(o);
    }

    public Myset Intersection(Myset a){
        Myset op=new Myset();


        for(int j=0;j<l.size();j++)
        {
            if(a.IsMember(l.get(j)))
                op.Insert(l.get(j));
        }
        return op;

    }

    public Myset Union(Myset a)
    {
        Myset op=new Myset();
        for(int j=0;j<l.size();j++)
        {
            op.Insert(l.get(j));
        }
        for(int j=0;j<a.l.size();j++)
        {
            op.Insert(a.l.get(j));
        }
        return op;

    }




}