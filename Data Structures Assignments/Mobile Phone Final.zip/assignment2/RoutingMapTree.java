import java.lang.String;
import java.lang.System;
import java.util.*;
import java.util.Scanner;

public class RoutingMapTree<T>{
    Exchange root;
    RoutingMapTree(){
       root = new Exchange(0);
    }
    public Exchange rSearch(Exchange node,int uid){

        if (node.get_element()==uid)
            return node;
        List<Exchange> listA = new ArrayList<>();
        listA = node.numChildren();
        Exchange temp = null;
        for (int i = 0; temp == null && i < listA.size(); i++) {
            temp = rSearch(listA.get(i),uid);
        }
        return temp;
    }


     public Boolean containsNode(Exchange node,int uid){

         if (node.get_element()==uid)
             return true;
         List<Exchange> listA = new ArrayList<>();
         listA = node.numChildren();
         Exchange temp = null;

         for (int i = 0; temp == null && i < listA.size(); i++) {
             temp = rSearch(listA.get(i),uid);
         }
         if(temp==null)
             return false;
         else return true;
    }
    public void switchOn(MobilePhone a, Exchange b){
        if(a.present_status==false) {
            a.present_status = true;
            Exchange nodeInTree ;
            nodeInTree= this.rSearch(this.root,b.u_id);
            this.inserter(a, nodeInTree);
        }
        else{
            Exchange nodeInTree ;
            nodeInTree= this.rSearch(this.root,b.u_id);
            this.inserter(a, nodeInTree);
        }
    }
            //write recursion
        public void inserter(MobilePhone a,Exchange node){
            if(node.isRoot()==false){
                node.mp_set.Insert(a);
                inserter(a,node.parent());
            }
            if(node.isRoot())
            {
                node.mp_set.Insert(a);
            }


        }



    public void switchOff(MobilePhone a, Exchange b){

            a.present_status=false;
            Exchange node1InTree ;
            node1InTree= this.rSearch(this.root,b.u_id);
            this.remover(a, node1InTree);



    }
    public void remover(MobilePhone a, Exchange node){
        if(node.isRoot()==false){
            node.mp_set.Delete(a);
            remover(a,node.parent());
        }
        if(node.isRoot())
        {
            node.mp_set.Delete(a);
        }


    }

    public void performAction(String actionMessage){
        //String key=actionMessage.substring(0,8);
        Scanner s =new Scanner(actionMessage);
        String newString=s.next();
        int a=0,b=0;
        if(s.hasNextInt())
             a=s.nextInt();
        if(s.hasNextInt())
             b=s.nextInt();
        System.out.println(actionMessage);
        if(newString.equals("addExchange"))
        {
            Exchange e1=new Exchange(b);
            if(this.containsNode(this.root,a)) {
            Exchange pNode = rSearch(this.root, a);
            pNode.addChild(e1, pNode);
            //add exceptions
        }
            else{
            System.out.println("NO EXCHANGE WITH GIVEN IDENTIFIER ");
        }
        }
        if(newString.equals("switchOnMobile"))
        {

            MobilePhone newMob= new MobilePhone(a);
            if(this.containsNode(this.root,b)) {
            Exchange Node = rSearch(this.root, b);
            this.switchOn(newMob, Node);
            /*MobilePhone newMob= new MobilePhone(a);
            Exchange Node = rSearch(this.root, b);
            Node.mp_set.Insert(newMob);
            */
        }
            else {
            System.out.println("NO EXCHANGE WITH GIVEN IDENTIFIER");
        }



        }
        if(newString.equals("switchOffMobile"))
        {
            MobilePhone fin=root.mp_set.getElement(a);
                    if(fin.mobile_uid==-1)
                    {
                        System.out.println("NO MOBILE PHONE WITH GIVEN ID");
                    }
            else
            root.mp_set.getElement(a).switchOff();

        }
        if(newString.equals("queryNthChild"))
        {
            Exchange Node = rSearch(this.root, a);
            System.out.println("" + Node.child(b).get_element());
        }
        if(newString.equals("queryMobilePhoneSet"))
        {
            Exchange Node = rSearch(this.root, a);
            for(int i=0;i<Node.mp_set.l.size();i++) {
                if(Node.mp_set.getElementAtIndex(i).present_status==true)
                System.out.println(" "+Node.mp_set.getElementAtIndex(i).mobile_uid);
            }
        }




        }


    }






