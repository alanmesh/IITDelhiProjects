import java.util.*;
/*public class Exchange<T>

{
    private Node<int> root;

    public Exchange(int exchange_id)
    {
        root = new Node<int>();
        root.set_element(exchange_id);
        root.set_Children(new ArrayList<Node<int>>());
    }

}*/

class Exchange<T>
{

    public Exchange(int exchange_id)
        {

        this.p=null;
        this.set_element(exchange_id);
        this.set_Children(new ArrayList<Exchange<T>>());
        }

    public int u_id;
    public Exchange<T> p;
    MobilePhoneSet mp_set=new MobilePhoneSet();
    //public Exchange<T> c;
    public List<Exchange<T>> children;

    public int get_element() {

        return u_id;
    }
    public void set_element(int data) {
        this.u_id = data;
    }

    public Exchange<T> parent() {
        return p;
    }

    public void set_Parent(Exchange<T> p1) {
        this.p = p1;
    }

    public List<Exchange<T>> numChildren() {
        return children;
    }

    public Exchange<T> child(int i){
       return children.get(i);
    }
    public boolean isRoot(){
        if(this.p==null){
        return true;}
        else return false;
        }
    //new methods for assgn3 form here
    public boolean hasChild()
    {
        if(this.children.size()==0)
            return false;
        else return true;
    }





    //new work ends here

//ADD METHOD & DELETE METHOD& DOES EXCHANGE EXIST&FINDING LOCATION
    public void addChild(Exchange new_node,Exchange parent_node ){
        new_node.set_Parent(parent_node);
        parent_node.children.add(new_node);

    }
    public void deleteExchange(Exchange e){

        e.parent().children.remove(e);

    }

    public void set_Children(List<Exchange<T>> children) {
        this.children = children;
    }
   /* public RoutingMapTree subtree(int i){



    }*/
  /* public MobilePhoneSet residentSet(){




   }*/
}