import java.lang.String;
import java.lang.System;
import java.util.*;
import java.util.Scanner;

public class RoutingMapTree<T>{
	Exchange root;
	RoutingMapTree(){
		root = new Exchange(0);
	}
	public Exchange rSearch(Exchange node,int uid){

		if (node.get_element()==uid)
			return node;
		List<Exchange> listA = new ArrayList<>();
		listA = node.numChildren();
		Exchange temp = null;
		for (int i = 0; temp == null && i < listA.size(); i++) {
			temp = rSearch(listA.get(i),uid);
		}
		return temp;
	}


	List<Exchange> levelZero = new ArrayList<>();
	public List<Exchange> getLevelZero(Exchange node){
		if(node.hasChild()==false){
			levelZero.add(node);}
		else {
			List<Exchange> listB = node.numChildren();
			for(int i=0;i<listB.size();i++)
			{
				this.getLevelZero(listB.get(i));
			}
		}

		return levelZero;

	}
	public Exchange getCommonAncestor(Exchange a,Exchange b){
		if(a==b){
			return a;
		}
		else
		{
			return getCommonAncestor(a.parent(),b.parent());}

	}
	public List<Exchange> getTrack(MobilePhone a, MobilePhone b){
		List<Exchange> listC = new ArrayList<>();
		Exchange exchangeA=findPhone(a);
		Exchange exchangeB=findPhone(b);
		Exchange commomParent=getCommonAncestor(exchangeA, exchangeB);
		Exchange curNode=exchangeA;
		listC.add(exchangeA);
		while (curNode!=commomParent){
			listC.add(curNode.parent());
			curNode=curNode.parent();
		}
		List<Exchange> listD = new ArrayList<>();
		Exchange tempNode=exchangeB;
		listD.add(tempNode);
		while (tempNode!=commomParent){
			listD.add(tempNode);
			tempNode=tempNode.parent();
		}
		for(int j=listD.size();j>0; j--){
			listC.add(listD.get(j-1));
		}
		return listC;


	}


	public Boolean containsNode(Exchange node,int uid){

		if (node.get_element()==uid)
			return true;
		List<Exchange> listA = new ArrayList<>();
		listA = node.numChildren();
		Exchange temp = null;

		for (int i = 0; temp == null && i < listA.size(); i++) {
			temp = rSearch(listA.get(i),uid);
		}
		if(temp==null)
			return false;
		else return true;
	}
	public void switchOn(MobilePhone a, Exchange b){
		if(a.present_status==false) {
			a.present_status = true;
			Exchange nodeInTree ;
			nodeInTree= this.rSearch(this.root,b.u_id);
			this.inserter(a, nodeInTree);
		}
		else{
			Exchange nodeInTree ;
			nodeInTree= this.rSearch(this.root,b.u_id);
			this.inserter(a, nodeInTree);
		}
	}
	//write recursion
	public void inserter(MobilePhone a,Exchange node){
		if(node.isRoot()==false){
			node.mp_set.Insert(a);
			inserter(a,node.parent());
		}
		if(node.isRoot())
		{
			node.mp_set.Insert(a);
		}


	}



	public void switchOff(MobilePhone a, Exchange b){

		a.present_status=false;
		Exchange node1InTree ;
		node1InTree= this.rSearch(this.root,b.u_id);
		this.remover(a, node1InTree);



	}
	public void remover(MobilePhone a, Exchange node){
		if(node.isRoot()==false){
			node.mp_set.Delete(a);
			remover(a,node.parent());
		}
		if(node.isRoot())
		{
			node.mp_set.Delete(a);
		}


	}

	//new functions for assgn3 start from here
	public Exchange findPhone(MobilePhone m) {
		try {
			this.getLevelZero(this.root);
			for (int j = 0; j < levelZero.size(); j++) {
				if (levelZero.get(j).mp_set.IsMember(m)) {
					return levelZero.get(j);

				}

			}

			throw new IllegalArgumentException("GIVEN MOBILE IS EITHER SWITCHED OFF/NOT FOUND");
		} catch (Exception e) {
			System.out.println("GIVEN MOBILE IS EITHER SWITCHED OFF/CAN'T BE FOUND");
			//continue;

		}
		return new Exchange(-1);

	}

	public Exchange lowestRouter(Exchange a, Exchange b){
		/*Exchange nodeA=this.rSearch(this.root,a.u_id);
		Exchange nodeB=this.rSearch(this.root,b.u_id);*/
		return getCommonAncestor(a,b);
	}
	public List<Exchange> routeCall(MobilePhone a, MobilePhone b)
	{

		return getTrack(a, b);
	}


	public void movePhone(MobilePhone a,Exchange b){
		if(a.present_status){
			Exchange exA=findPhone(a);
			switchOff(a,exA);
			switchOn(a, b);

		}
	}









	//new functions for assgn3 end here

	public void performAction(String actionMessage){
		//String key=actionMessage.substring(0,8);
		Scanner s =new Scanner(actionMessage);
		String newString=s.next();
		int a=0,b=0;
		if(s.hasNextInt())
			a=s.nextInt();
		if(s.hasNextInt())
			b=s.nextInt();
		System.out.println(actionMessage);
		if(newString.equals("addExchange"))
		{
			Exchange e1=new Exchange(b);
			if(this.containsNode(this.root,a)) {
				Exchange pNode = rSearch(this.root, a);
				pNode.addChild(e1, pNode);
				//add exceptions
			}
			else{
				System.out.println("NO EXCHANGE WITH GIVEN IDENTIFIER ");
			}
		}
		if(newString.equals("switchOnMobile"))
		{

			MobilePhone newMob= new MobilePhone(a);
			if(this.containsNode(this.root,b)) {
				Exchange Node = rSearch(this.root, b);
				this.switchOn(newMob, Node);
            /*MobilePhone newMob= new MobilePhone(a);
            Exchange Node = rSearch(this.root, b);
            Node.mp_set.Insert(newMob);
            */
			}
			else {
				System.out.println("NO EXCHANGE WITH GIVEN IDENTIFIER");
			}



		}
		if(newString.equals("switchOffMobile"))
		{
			MobilePhone fin=root.mp_set.getElement(a);
			if(fin.mobile_uid==-1)
			{
				System.out.println("NO MOBILE PHONE WITH GIVEN ID");
			}
			else
				root.mp_set.getElement(a).switchOff();

		}
		if(newString.equals("queryNthChild"))
		{
			Exchange Node = rSearch(this.root, a);
			System.out.println("" + Node.child(b).get_element());
		}
		if(newString.equals("queryMobilePhoneSet"))
		{
			Exchange Node = rSearch(this.root, a);
			for(int i=0;i<Node.mp_set.l.size();i++) {
				if(Node.mp_set.getElementAtIndex(i).present_status==true)
					System.out.println(" "+Node.mp_set.getElementAtIndex(i).mobile_uid);
			}
		}
		if(newString.equals("findPhone")){

			MobilePhone newMob=root.mp_set.getElement(a);
			System.out.println(""+findPhone(newMob).u_id);

		}

		if(newString.equals("lowestRouter")){
			Exchange newA=rSearch(this.root,a);
			Exchange newB=rSearch(this.root, b);


			System.out.println("" + lowestRouter(newA, newB).u_id);

		}
		if(newString.equals("findCallPath")){
			MobilePhone newA=root.mp_set.getElement(a);
			MobilePhone newB=root.mp_set.getElement(b);
			List<Exchange> listE=routeCall(newA,newB);
			for (int i=1;i<listE.size();i++)
			{
				System.out.print(listE.get(i - 1).u_id + ",");
			}
			System.out.println();

		}
		if(newString.equals("movePhone")){

			MobilePhone mobToMove=root.mp_set.getElement(a);
			Exchange newExg=rSearch(this.root,b);
			movePhone(mobToMove,newExg);


		}

	}

}






